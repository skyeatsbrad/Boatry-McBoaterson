import asyncio
"""
Survivor - A Vampire Survivors-style game built with Pygame.
Features: multiple weapons, bosses, dash, particles, screen shake,
persistent upgrades, character select, achievements, minimap, and more.
"""

import pygame
import sys
import math
import random
import json
import array as arr_module


HAS_UPDATER = False

# ===========================================================================
# Section 1: Constants
# ===========================================================================
SCREEN_W, SCREEN_H = 960, 720
FPS = 60
FONT_NAME = None

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (220, 40, 40)
GREEN = (50, 200, 50)
BLUE = (60, 120, 220)
YELLOW = (255, 220, 40)
PURPLE = (160, 60, 220)
CYAN = (60, 220, 220)
ORANGE = (240, 150, 30)
DARK_GRAY = (30, 30, 40)
GRAY = (80, 80, 100)
LIGHT_GRAY = (160, 160, 180)
DARK_RED = (100, 15, 15)
GOLD = (255, 200, 50)
PINK = (255, 100, 150)
TEAL = (0, 180, 180)

WORLD_W, WORLD_H = 3000, 3000
TILE_SIZE = 64

PLAYER_RADIUS = 20
PLAYER_SPEED = 3.0
PLAYER_BASE_HP = 120
INVULN_TIME = 0.4
DASH_SPEED = 12
DASH_DURATION = 8
DASH_COOLDOWN = 90

PROJ_SPEED = 7
PROJ_RADIUS = 5
PROJ_DAMAGE = 20
PROJ_LIFETIME = 60
PROJ_COOLDOWN = 30

ENEMY_RADIUS = 12
ENEMY_BASE_SPEED = 0.9
ENEMY_BASE_HP = 25
ENEMY_DAMAGE = 8
SPAWN_DIST_MIN = 450
SPAWN_DIST_MAX = 650

GEM_RADIUS = 6
GEM_ATTRACT_DIST = 100
GEM_ATTRACT_SPEED = 5

INITIAL_SPAWN_RATE = 120
MIN_SPAWN_RATE = 25
WAVE_DURATION = 45
BOSS_WAVE_INTERVAL = 5

MINIMAP_SIZE = 120
MINIMAP_MARGIN = 10

SAVE_FILE = "save_data.json"


# ===========================================================================
# Section 2: Helpers
# ===========================================================================
def dist(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])

def angle_to(a, b):
    return math.atan2(b[1] - a[1], b[0] - a[0])

def clamp(v, lo, hi):
    return max(lo, min(hi, v))

def lerp(a, b, t):
    return a + (b - a) * t

_font_cache = {}
def get_font(size):
    if size not in _font_cache:
        _font_cache[size] = pygame.font.Font(FONT_NAME, size)
    return _font_cache[size]

def draw_text(surface, text, size, x, y, color=WHITE, center=False):
    font = get_font(size)
    img = font.render(str(text), True, color)
    rect = img.get_rect(center=(x, y)) if center else img.get_rect(topleft=(x, y))
    surface.blit(img, rect)
    return rect

def draw_bar(surface, x, y, w, h, ratio, color, bg=GRAY):
    pygame.draw.rect(surface, bg, (x, y, w, h))
    pygame.draw.rect(surface, color, (x, y, int(w * clamp(ratio, 0, 1)), h))
    pygame.draw.rect(surface, WHITE, (x, y, w, h), 1)


# ===========================================================================
# Section 3: Save / Load System
# ===========================================================================
DEFAULT_SAVE = {
    "gold": 0,
    "upgrades": {"max_hp": 0, "damage": 0, "speed": 0, "xp_bonus": 0},
    "high_scores": [],
    "achievements": [],
    "settings": {"sfx_volume": 0.7, "fullscreen": False},
    "total_kills": 0,
    "total_runs": 0,
}

def load_save():
    try:
        with open(SAVE_FILE, "r") as f:
            data = json.load(f)
        for k, v in DEFAULT_SAVE.items():
            if k not in data:
                data[k] = v if not isinstance(v, (dict, list)) else json.loads(json.dumps(v))
        return data
    except Exception:
        return json.loads(json.dumps(DEFAULT_SAVE))

def save_game(data):
    try:
        with open(SAVE_FILE, "w") as f:
            json.dump(data, f, indent=2)
    except Exception:
        pass


# ===========================================================================
# Section 4: Sound System
# ===========================================================================
class SoundManager:
    def __init__(self):
        try:
            pygame.mixer.init(frequency=22050, size=-16, channels=1, buffer=512)
            self.enabled = True
        except Exception:
            self.enabled = False
        self.sounds = {}
        self.volume = 0.5
        if self.enabled:
            self._generate_sounds()

    def _tone(self, freq, dur, vol=0.3, wave="sine"):
        sr = 22050
        n = int(sr * dur)
        buf = arr_module.array("h", [0] * n)
        for i in range(n):
            t = i / sr
            env = max(0, 1 - i / n)
            if wave == "sine":
                v = math.sin(2 * math.pi * freq * t)
            elif wave == "square":
                v = 1 if math.sin(2 * math.pi * freq * t) > 0 else -1
            elif wave == "noise":
                v = random.uniform(-1, 1)
            else:
                v = math.sin(2 * math.pi * freq * t)
            buf[i] = int(v * vol * env * 32767)
        return pygame.mixer.Sound(buffer=buf)

    def _generate_sounds(self):
        self.sounds["shoot"] = self._tone(600, 0.08, 0.2)
        self.sounds["hit"] = self._tone(200, 0.1, 0.25, "square")
        self.sounds["kill"] = self._tone(800, 0.12, 0.2)
        self.sounds["gem"] = self._tone(1200, 0.06, 0.15)
        self.sounds["levelup"] = self._tone(880, 0.3, 0.3)
        self.sounds["dash"] = self._tone(400, 0.15, 0.2, "noise")
        self.sounds["hurt"] = self._tone(150, 0.2, 0.3, "square")
        self.sounds["boss_roar"] = self._tone(80, 0.5, 0.4, "square")
        self.sounds["explosion"] = self._tone(100, 0.3, 0.35, "noise")
        self.sounds["lightning"] = self._tone(1500, 0.1, 0.2, "square")
        self.sounds["heal"] = self._tone(1000, 0.2, 0.2)
        self.sounds["chest"] = self._tone(660, 0.15, 0.25)
        self.sounds["achievement"] = self._tone(1100, 0.4, 0.3)
        self.sounds["select"] = self._tone(500, 0.05, 0.15)
        self.sounds["boomerang"] = self._tone(350, 0.12, 0.2)

    def play(self, name):
        if self.enabled and name in self.sounds:
            s = self.sounds[name]
            s.set_volume(self.volume)
            s.play()

    def set_volume(self, vol):
        self.volume = clamp(vol, 0, 1)


# ===========================================================================
# Section 5: Particle System
# ===========================================================================
class Particle:
    __slots__ = ("x", "y", "vx", "vy", "color", "life", "max_life", "size", "shrink", "glow")

    def __init__(self, x, y, vx, vy, color, life=20, size=3, shrink=True, glow=False):
        self.x, self.y = x, y
        self.vx, self.vy = vx, vy
        self.color = color
        self.life = self.max_life = life
        self.size = size
        self.shrink = shrink
        self.glow = glow

    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.vx *= 0.96
        self.vy *= 0.96
        self.life -= 1

    def draw(self, surface, cam_x, cam_y):
        alpha = self.life / self.max_life
        sz = self.size * alpha if self.shrink else self.size
        if sz < 0.5:
            return
        sx, sy = int(self.x - cam_x), int(self.y - cam_y)
        c = tuple(int(ch * alpha) for ch in self.color)
        if self.glow and sz > 2:
            glow_surf = pygame.Surface((int(sz * 4), int(sz * 4)), pygame.SRCALPHA)
            pygame.draw.circle(glow_surf, (*self.color, int(40 * alpha)),
                               (int(sz * 2), int(sz * 2)), int(sz * 2))
            surface.blit(glow_surf, (sx - int(sz * 2), sy - int(sz * 2)))
        pygame.draw.circle(surface, c, (sx, sy), max(1, int(sz)))


class ParticleSystem:
    def __init__(self):
        self.particles = []

    def emit(self, x, y, color, count=8, speed=3, life=20, size=3, glow=False):
        for _ in range(count):
            a = random.uniform(0, math.pi * 2)
            sp = random.uniform(speed * 0.3, speed)
            self.particles.append(
                Particle(x, y, math.cos(a) * sp, math.sin(a) * sp,
                         color, life + random.randint(-5, 5), size, glow=glow))

    def update(self):
        self.particles = [p for p in self.particles if p.life > 0]
        for p in self.particles:
            p.update()

    def draw(self, surface, cam_x, cam_y):
        for p in self.particles:
            p.draw(surface, cam_x, cam_y)


# ===========================================================================
# Section 6: Screen Shake
# ===========================================================================
class ScreenShake:
    def __init__(self):
        self.amount = 0
        self.offset_x = 0
        self.offset_y = 0

    def shake(self, intensity):
        self.amount = max(self.amount, intensity)

    def update(self):
        if self.amount > 0.5:
            self.offset_x = random.uniform(-self.amount, self.amount)
            self.offset_y = random.uniform(-self.amount, self.amount)
            self.amount *= 0.85
        else:
            self.amount = self.offset_x = self.offset_y = 0


# ===========================================================================
# Section 7: Weapon Entities
# ===========================================================================
class Projectile:
    def __init__(self, x, y, angle, speed, damage, color=YELLOW,
                 radius=PROJ_RADIUS, life=PROJ_LIFETIME):
        self.x, self.y = x, y
        self.vx = math.cos(angle) * speed
        self.vy = math.sin(angle) * speed
        self.radius = radius
        self.damage = damage
        self.life = life
        self.color = color

    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.life -= 1

    def draw(self, surface, cam_x, cam_y):
        sx, sy = int(self.x - cam_x), int(self.y - cam_y)
        pygame.draw.circle(surface, self.color, (sx, sy), self.radius)
        pygame.draw.circle(surface, WHITE, (sx, sy), self.radius, 1)


class Boomerang:
    def __init__(self, x, y, angle, speed, damage, owner_ref):
        self.x, self.y = x, y
        self.angle = angle
        self.speed = speed
        self.damage = damage
        self.radius = 8
        self.color = TEAL
        self.phase = "out"
        self.dist_traveled = 0
        self.max_dist = 200
        self.rotation = 0
        self.owner_ref = owner_ref  # mutable list [px, py]
        self.hit_enemies = set()

    def update(self):
        self.rotation += 0.3
        if self.phase == "out":
            self.x += math.cos(self.angle) * self.speed
            self.y += math.sin(self.angle) * self.speed
            self.dist_traveled += self.speed
            if self.dist_traveled >= self.max_dist:
                self.phase = "return"
                self.hit_enemies.clear()
        else:
            a = angle_to((self.x, self.y), (self.owner_ref[0], self.owner_ref[1]))
            self.x += math.cos(a) * self.speed * 1.2
            self.y += math.sin(a) * self.speed * 1.2

    @property
    def returned(self):
        return (self.phase == "return" and
                dist((self.x, self.y), (self.owner_ref[0], self.owner_ref[1])) < 30)

    def draw(self, surface, cam_x, cam_y):
        sx, sy = int(self.x - cam_x), int(self.y - cam_y)
        pts = []
        for i in range(4):
            a = self.rotation + i * math.pi / 2
            pts.append((sx + math.cos(a) * self.radius,
                        sy + math.sin(a) * self.radius))
        pygame.draw.polygon(surface, self.color, pts)
        pygame.draw.polygon(surface, WHITE, pts, 1)


class LightningBolt:
    def __init__(self, x, y, targets, damage):
        self.segments = []
        self.damage = damage
        self.life = 12
        cx, cy = x, y
        for tx, ty in targets:
            self.segments.append(((cx, cy), (tx, ty)))
            cx, cy = tx, ty

    def update(self):
        self.life -= 1

    def draw(self, surface, cam_x, cam_y):
        alpha = self.life / 12
        for (x1, y1), (x2, y2) in self.segments:
            sx1, sy1 = int(x1 - cam_x), int(y1 - cam_y)
            sx2, sy2 = int(x2 - cam_x), int(y2 - cam_y)
            c = tuple(int(ch * alpha) for ch in CYAN)
            w = max(1, int(3 * alpha))
            mid_x = (sx1 + sx2) // 2 + random.randint(-8, 8)
            mid_y = (sy1 + sy2) // 2 + random.randint(-8, 8)
            pygame.draw.line(surface, c, (sx1, sy1), (mid_x, mid_y), w)
            pygame.draw.line(surface, c, (mid_x, mid_y), (sx2, sy2), w)


class ExplosionEffect:
    def __init__(self, x, y, radius, damage, color=ORANGE):
        self.x, self.y = x, y
        self.max_radius = radius
        self.damage = damage
        self.color = color
        self.life = 15
        self.max_life = 15

    def update(self):
        self.life -= 1

    def draw(self, surface, cam_x, cam_y):
        alpha = self.life / self.max_life
        sx, sy = int(self.x - cam_x), int(self.y - cam_y)
        r = int(self.max_radius * (1 - alpha * 0.3))
        if r < 1:
            return
        surf = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
        pygame.draw.circle(surf, (*self.color, int(100 * alpha)), (r, r), r)
        pygame.draw.circle(surf, (*WHITE, int(60 * alpha)), (r, r), max(1, r // 2))
        surface.blit(surf, (sx - r, sy - r))


# ===========================================================================
# Section 8: Game Entities
# ===========================================================================
CHARACTERS = [
    {"name": "Tugboat", "color": BLUE,
     "desc": "Balanced fighter. Cannon weapon.",
     "hp_mod": 1.0, "spd_mod": 1.0, "dmg_mod": 1.0, "weapon": "projectile"},
    {"name": "Warship", "color": PURPLE,
     "desc": "Slow tank. Lightning mast.",
     "hp_mod": 1.4, "spd_mod": 0.7, "dmg_mod": 1.3, "weapon": "lightning"},
    {"name": "Speedboat", "color": GREEN,
     "desc": "Fast & fragile. Anchor boomerang.",
     "hp_mod": 0.8, "spd_mod": 1.3, "dmg_mod": 1.0, "weapon": "boomerang"},
]


class Player:
    def __init__(self, char_idx=0, upgrades=None):
        ch = CHARACTERS[char_idx]
        ups = upgrades or {"max_hp": 0, "damage": 0, "speed": 0, "xp_bonus": 0}
        self.char_idx = char_idx
        self.char_color = ch["color"]
        self.x = WORLD_W / 2
        self.y = WORLD_H / 2
        self.radius = PLAYER_RADIUS
        self.max_hp = int((PLAYER_BASE_HP + ups["max_hp"] * 10) * ch["hp_mod"])
        self.hp = self.max_hp
        self.speed = (PLAYER_SPEED + ups["speed"] * 0.2) * ch["spd_mod"]
        self.xp = 0
        self.level = 1
        self.xp_to_next = 20
        self.xp_bonus = 1.0 + ups["xp_bonus"] * 0.1
        self.proj_damage = int((PROJ_DAMAGE + ups["damage"] * 5) * ch["dmg_mod"])
        self.proj_speed = PROJ_SPEED
        self.proj_count = 1
        self.proj_cooldown = PROJ_COOLDOWN
        self.cooldown_timer = 0
        self.invuln_timer = 0
        self.kills = 0
        self.gold = 0
        self.powerups_chosen = 0
        self.weapon = ch["weapon"]

        # Dash
        self.dash_timer = 0
        self.dash_cooldown_timer = 0
        self.dash_dx = 0
        self.dash_dy = 0
        self.dashes_used = 0

        # Orbit
        self.has_orbit = False
        self.orbit_count = 3
        self.orbit_radius = 70
        self.orbit_damage = 15
        self.orbit_angle = 0.0
        self.orbit_speed = 0.05

        # Aura
        self.has_aura = False
        self.aura_radius = 80
        self.aura_damage = 5
        self.aura_tick = 0

        # Lightning weapon timers
        self.lightning_cooldown = 45
        self.lightning_timer = 0
        self.lightning_chains = 3
        self.lightning_range = 150

        # Boomerang weapon timers
        self.boomerang_cooldown = 50
        self.boomerang_timer = 0
        self.boomerang_count = 1

        # Explosion ability
        self.has_explosion = False
        self.explosion_cooldown = 120
        self.explosion_timer = 0
        self.explosion_radius = 100
        self.explosion_damage = 30

        # Animation
        self.bob_timer = 0
        self.facing_x = 1

    def gain_xp(self, amount):
        self.xp += int(amount * self.xp_bonus)
        while self.xp >= self.xp_to_next:
            self.xp -= self.xp_to_next
            self.level += 1
            self.xp_to_next = int(self.xp_to_next * 1.4)
            return True
        return False

    def start_dash(self, keys):
        if self.dash_cooldown_timer > 0 or self.dash_timer > 0:
            return False
        dx = dy = 0
        if keys[pygame.K_w] or keys[pygame.K_UP]: dy -= 1
        if keys[pygame.K_s] or keys[pygame.K_DOWN]: dy += 1
        if keys[pygame.K_a] or keys[pygame.K_LEFT]: dx -= 1
        if keys[pygame.K_d] or keys[pygame.K_RIGHT]: dx += 1
        if dx == 0 and dy == 0:
            dx = self.facing_x
        mag = math.hypot(dx, dy)
        if mag > 0:
            self.dash_dx = dx / mag
            self.dash_dy = dy / mag
        self.dash_timer = DASH_DURATION
        self.dash_cooldown_timer = DASH_COOLDOWN
        self.invuln_timer = DASH_DURATION / FPS + 0.05
        self.dashes_used += 1
        return True

    def update(self, keys):
        self.bob_timer += 0.1
        if self.dash_timer > 0:
            self.x += self.dash_dx * DASH_SPEED
            self.y += self.dash_dy * DASH_SPEED
            self.dash_timer -= 1
        else:
            dx = dy = 0
            if keys[pygame.K_w] or keys[pygame.K_UP]: dy -= 1
            if keys[pygame.K_s] or keys[pygame.K_DOWN]: dy += 1
            if keys[pygame.K_a] or keys[pygame.K_LEFT]: dx -= 1
            if keys[pygame.K_d] or keys[pygame.K_RIGHT]: dx += 1
            if dx != 0:
                self.facing_x = dx
            if dx or dy:
                mag = math.hypot(dx, dy)
                self.x += dx / mag * self.speed
                self.y += dy / mag * self.speed

        self.x = clamp(self.x, self.radius, WORLD_W - self.radius)
        self.y = clamp(self.y, self.radius, WORLD_H - self.radius)

        if self.invuln_timer > 0: self.invuln_timer -= 1 / FPS
        if self.cooldown_timer > 0: self.cooldown_timer -= 1
        if self.dash_cooldown_timer > 0: self.dash_cooldown_timer -= 1
        if self.lightning_timer > 0: self.lightning_timer -= 1
        if self.boomerang_timer > 0: self.boomerang_timer -= 1
        if self.explosion_timer > 0: self.explosion_timer -= 1
        if self.has_orbit: self.orbit_angle += self.orbit_speed
        if self.has_aura: self.aura_tick += 1

    def draw(self, surface, cam_x, cam_y):
        sx = int(self.x - cam_x)
        sy = int(self.y - cam_y)
        bob = math.sin(self.bob_timer) * 3
        arm_flex = math.sin(self.bob_timer * 3) * 0.2 + 1.0
        ex = 1 if self.facing_x >= 0 else -1

        # Aura glow
        if self.has_aura:
            aura_surf = pygame.Surface(
                (self.aura_radius * 2, self.aura_radius * 2), pygame.SRCALPHA)
            pulse = int(40 + 20 * math.sin(pygame.time.get_ticks() / 250.0))
            pygame.draw.circle(aura_surf, (100, 200, 255, pulse),
                               (self.aura_radius, self.aura_radius), self.aura_radius)
            surface.blit(aura_surf, (sx - self.aura_radius, sy - self.aura_radius))

        # Orbital blades
        if self.has_orbit:
            for i in range(self.orbit_count):
                a = self.orbit_angle + (2 * math.pi * i / self.orbit_count)
                ox = sx + math.cos(a) * self.orbit_radius
                oy = sy + math.sin(a) * self.orbit_radius
                pygame.draw.circle(surface, CYAN, (int(ox), int(oy)), 7)
                pygame.draw.circle(surface, WHITE, (int(ox), int(oy)), 7, 1)

        # Wake/splash behind boat
        for i in range(4):
            wx = sx - ex * (16 + i * 8)
            wy = int(sy + bob + 8 + random.randint(-2, 2))
            wa = max(0, 100 - i * 25)
            ws = pygame.Surface((10, 6), pygame.SRCALPHA)
            pygame.draw.ellipse(ws, (180, 210, 240, wa), (0, 0, 10, 6))
            surface.blit(ws, (wx - 5, wy - 3))

        # Dash ghost trail
        if self.dash_timer > 0:
            for i in range(4):
                gx = sx - self.dash_dx * (i + 1) * 10
                gy = sy + bob - self.dash_dy * (i + 1) * 10
                ghost = pygame.Surface((50, 30), pygame.SRCALPHA)
                a = 90 - i * 22
                pygame.draw.ellipse(ghost, (*self.char_color, a), (2, 4, 46, 22))
                surface.blit(ghost, (int(gx) - 25, int(gy) - 15))

        blink = self.invuln_timer > 0 and int(self.invuln_timer * 10) % 2
        if not blink:
            by = int(sy + bob)
            cc = self.char_color
            lighter = tuple(min(c + 40, 255) for c in cc)
            darker = tuple(max(c - 40, 0) for c in cc)

            # === BOAT HULL ===
            # Main hull (rounded shape)
            hull_pts = [
                (sx - 22 * ex, by + 10), (sx - 20 * ex, by - 8),
                (sx - 10 * ex, by - 12), (sx + 5 * ex, by - 12),
                (sx + 20 * ex, by - 6), (sx + 26 * ex, by),
                (sx + 20 * ex, by + 8), (sx - 5 * ex, by + 12),
                (sx - 22 * ex, by + 10)]
            pygame.draw.polygon(surface, cc, hull_pts)
            pygame.draw.polygon(surface, WHITE, hull_pts, 2)
            # Hull stripe
            pygame.draw.line(surface, lighter,
                             (sx - 20 * ex, by + 2), (sx + 22 * ex, by + 2), 2)
            # Bow highlight
            pygame.draw.line(surface, WHITE,
                             (sx + 22 * ex, by - 4), (sx + 26 * ex, by), 2)

            # Cabin / wheelhouse
            cab_w, cab_h = 14, 12
            cab_x = sx - 8 * ex
            pygame.draw.rect(surface, lighter,
                             (cab_x - cab_w // 2, by - 12 - cab_h, cab_w, cab_h))
            pygame.draw.rect(surface, WHITE,
                             (cab_x - cab_w // 2, by - 12 - cab_h, cab_w, cab_h), 1)
            # Window
            pygame.draw.rect(surface, (140, 200, 240),
                             (cab_x - 3, by - 12 - cab_h + 3, 6, 4))
            # Smokestack
            pygame.draw.rect(surface, darker,
                             (cab_x - 2, by - 12 - cab_h - 6, 4, 6))
            # Smoke puffs
            smoke_off = int(self.bob_timer * 5) % 20
            for i in range(3):
                sa = max(0, 60 - i * 20 - smoke_off)
                ssurf = pygame.Surface((12, 12), pygame.SRCALPHA)
                pygame.draw.circle(ssurf, (200, 200, 210, sa), (6, 6), 4 + i)
                surface.blit(ssurf, (cab_x - 6, by - 12 - cab_h - 12 - i * 6 - smoke_off))

            # === MUSCULAR ARMS ===
            skin = (220, 175, 130)
            skin_dk = (185, 145, 100)
            skin_hi = (240, 200, 160)
            bicep_r = int(6 * arm_flex)

            # Left arm
            ls = (sx - 20, by - 4)
            le = (sx - 32, int(by - 14 * arm_flex))
            lh = (sx - 36, int(by - 24 * arm_flex))
            pygame.draw.line(surface, skin_dk, ls, le, int(7 * arm_flex))
            pygame.draw.circle(surface, skin, ((ls[0]+le[0])//2, (ls[1]+le[1])//2), bicep_r)
            pygame.draw.circle(surface, skin_hi, ((ls[0]+le[0])//2 - 1, (ls[1]+le[1])//2 - 2),
                               max(1, bicep_r - 2))
            pygame.draw.line(surface, skin_dk, le, lh, 5)
            pygame.draw.circle(surface, skin, lh, 5)

            # Right arm
            rs = (sx + 20, by - 4)
            re = (sx + 32, int(by - 14 * arm_flex))
            rh = (sx + 36, int(by - 24 * arm_flex))
            pygame.draw.line(surface, skin_dk, rs, re, int(7 * arm_flex))
            pygame.draw.circle(surface, skin, ((rs[0]+re[0])//2, (rs[1]+re[1])//2), bicep_r)
            pygame.draw.circle(surface, skin_hi, ((rs[0]+re[0])//2 + 1, (rs[1]+re[1])//2 - 2),
                               max(1, bicep_r - 2))
            pygame.draw.line(surface, skin_dk, re, rh, 5)
            pygame.draw.circle(surface, skin, rh, 5)

            # === FACE ===
            # Eyes (larger, more expressive)
            pygame.draw.circle(surface, WHITE, (sx - 5 * ex, by - 5), 5)
            pygame.draw.circle(surface, WHITE, (sx + 7 * ex, by - 5), 5)
            pygame.draw.circle(surface, BLACK, (sx - 4 * ex, by - 5), 3)
            pygame.draw.circle(surface, BLACK, (sx + 8 * ex, by - 5), 3)
            # Eyebrows (determined look)
            pygame.draw.line(surface, darker,
                             (sx - 9 * ex, by - 10), (sx - 1 * ex, by - 9), 2)
            pygame.draw.line(surface, darker,
                             (sx + 3 * ex, by - 9), (sx + 11 * ex, by - 10), 2)
            # Smile
            pygame.draw.arc(surface, darker,
                            (sx - 5, by - 1, 10, 6), 3.14, 6.28, 2)

        # Dash cooldown indicator
        if self.dash_cooldown_timer > 0:
            ratio = 1 - self.dash_cooldown_timer / DASH_COOLDOWN
            draw_bar(surface, sx - 15, int(sy + bob) + self.radius + 4,
                     30, 3, ratio, CYAN, DARK_GRAY)


class Enemy:
    def __init__(self, x, y, wave):
        self.x, self.y = x, y
        self.radius = ENEMY_RADIUS + random.randint(-2, 4)
        scale = 1 + wave * 0.08
        self.max_hp = int(ENEMY_BASE_HP * scale)
        self.hp = self.max_hp
        self.speed = ENEMY_BASE_SPEED + random.uniform(-0.2, 0.3) + wave * 0.05
        self.damage = ENEMY_DAMAGE + wave * 2
        self.xp_value = 5 + wave
        self.gold_value = 1 + wave // 2
        self.hit_flash = 0
        self.is_boss = False
        self.anim_timer = random.uniform(0, math.pi * 2)
        self.drop_chance = 0.05

        variant = random.random()
        if variant < 0.15 and wave >= 2:
            self.max_hp = int(self.max_hp * 2.5)
            self.hp = self.max_hp
            self.speed *= 0.6
            self.radius += 6
            self.xp_value *= 3
            self.gold_value *= 2
            self.color = PURPLE
            self.damage = int(self.damage * 1.5)
            self.variant = "tank"
        elif variant < 0.3 and wave >= 1:
            self.speed *= 1.8
            self.max_hp = int(self.max_hp * 0.6)
            self.hp = self.max_hp
            self.color = ORANGE
            self.variant = "fast"
        else:
            self.color = RED
            self.variant = "normal"

    def update(self, px, py):
        a = angle_to((self.x, self.y), (px, py))
        self.x += math.cos(a) * self.speed
        self.y += math.sin(a) * self.speed
        if self.hit_flash > 0:
            self.hit_flash -= 1
        self.anim_timer += 0.08

    def draw(self, surface, cam_x, cam_y):
        sx, sy = int(self.x - cam_x), int(self.y - cam_y)
        bob = math.sin(self.anim_timer) * 3
        tail_wag = math.sin(self.anim_timer * 2) * 4
        sy_b = int(sy + bob)
        color = WHITE if self.hit_flash > 0 else self.color
        r = self.radius
        lighter = tuple(min(c + 50, 255) for c in self.color)
        darker = tuple(max(c - 40, 0) for c in self.color)

        # === FISH BODY ===
        # Tail fin (behind body)
        pygame.draw.polygon(surface, darker, [
            (sx - r + 2, sy_b),
            (sx - r - 10, int(sy_b - 8 + tail_wag)),
            (sx - r - 10, int(sy_b + 8 + tail_wag))])
        # Main body (ellipse)
        body_rect = pygame.Rect(sx - r, sy_b - r * 2 // 3, r * 2, r * 4 // 3)
        pygame.draw.ellipse(surface, color, body_rect)
        # Belly (lighter underside)
        belly_rect = pygame.Rect(sx - r + 3, sy_b, r * 2 - 6, r * 2 // 3 - 2)
        pygame.draw.ellipse(surface, lighter, belly_rect)
        # Body outline
        pygame.draw.ellipse(surface, BLACK, body_rect, 2)
        # Dorsal fin
        pygame.draw.polygon(surface, darker, [
            (sx - 2, sy_b - r * 2 // 3),
            (sx - 6, sy_b - r - 4),
            (sx + 4, sy_b - r * 2 // 3)])

        if self.variant == "tank":
            # Pufferfish spikes
            for i in range(10):
                a = self.anim_timer * 0.3 + i * math.pi / 5
                spx = sx + math.cos(a) * (r + 3)
                spy = sy_b + math.sin(a) * (r * 2 // 3 + 2)
                pygame.draw.line(surface, darker,
                                 (sx + int(math.cos(a) * r),
                                  sy_b + int(math.sin(a) * r * 2 // 3)),
                                 (int(spx), int(spy)), 2)
        if self.variant == "fast":
            # Swordfish nose blade
            pygame.draw.polygon(surface, lighter, [
                (sx + r, sy_b - 2), (sx + r + 14, sy_b), (sx + r, sy_b + 2)])
            pygame.draw.line(surface, WHITE, (sx + r, sy_b), (sx + r + 14, sy_b), 1)

        # Eye
        pygame.draw.circle(surface, WHITE, (sx + r // 2, sy_b - r // 4), 4)
        pygame.draw.circle(surface, BLACK, (sx + r // 2 + 1, sy_b - r // 4), 2)
        # Mouth
        pygame.draw.arc(surface, BLACK,
                        (sx + r - 5, sy_b - 1, 8, 6), 3.14, 6.28, 2)

        # HP bar
        if self.hp < self.max_hp:
            bw = max(20, r * 2)
            draw_bar(surface, sx - bw // 2, sy_b - r - 10,
                     bw, 4, self.hp / self.max_hp, RED)


class Boss(Enemy):
    def __init__(self, x, y, wave):
        super().__init__(x, y, wave)
        self.is_boss = True
        self.radius = 32 + wave * 2
        self.max_hp = int(ENEMY_BASE_HP * (8 + wave * 3))
        self.hp = self.max_hp
        self.speed = ENEMY_BASE_SPEED * 0.7
        self.damage = ENEMY_DAMAGE * 3 + wave * 4
        self.xp_value = 50 + wave * 20
        self.gold_value = 20 + wave * 10
        self.color = DARK_RED
        self.variant = "boss"
        self.drop_chance = 1.0

    def draw(self, surface, cam_x, cam_y):
        sx, sy = int(self.x - cam_x), int(self.y - cam_y)
        pulse = math.sin(self.anim_timer) * 3
        r = int(self.radius + pulse)
        # Dark aura
        aura = pygame.Surface((r * 3, r * 3), pygame.SRCALPHA)
        pygame.draw.circle(aura, (80, 0, 80, 30), (r * 3 // 2, r * 3 // 2), r * 3 // 2)
        surface.blit(aura, (sx - r * 3 // 2, sy - r * 3 // 2))
        color = WHITE if self.hit_flash > 0 else self.color
        # Kraken body
        pygame.draw.circle(surface, color, (sx, sy), r)
        pygame.draw.circle(surface, (100, 20, 20), (sx, sy), r, 3)
        # Tentacles
        for i in range(6):
            a = self.anim_timer * 0.5 + i * math.pi / 3
            wave_off = math.sin(self.anim_timer * 2 + i) * 8
            tx = sx + math.cos(a) * (r + 10)
            ty = sy + math.sin(a) * (r + 10) + wave_off
            tx2 = sx + math.cos(a) * (r + 25)
            ty2 = sy + math.sin(a) * (r + 25) - wave_off
            pygame.draw.line(surface, color, (int(tx), int(ty)),
                             (int(tx2), int(ty2)), 4)
            pygame.draw.circle(surface, color, (int(tx2), int(ty2)), 3)
        # Glowing eyes
        pygame.draw.circle(surface, YELLOW, (sx - 10, sy - 5), 7)
        pygame.draw.circle(surface, YELLOW, (sx + 10, sy - 5), 7)
        pygame.draw.circle(surface, RED, (sx - 10, sy - 5), 4)
        pygame.draw.circle(surface, RED, (sx + 10, sy - 5), 4)
        # Crown
        pts = [(sx - 12, sy - r - 2), (sx - 8, sy - r - 12),
               (sx - 2, sy - r - 4), (sx + 4, sy - r - 14),
               (sx + 10, sy - r - 4), (sx + 14, sy - r - 12),
               (sx + 18, sy - r - 2)]
        pygame.draw.polygon(surface, GOLD, pts)
        # HP bar
        bw = min(200, self.radius * 4)
        draw_bar(surface, sx - bw // 2, sy - r - 20, bw, 8,
                 self.hp / self.max_hp, RED, DARK_RED)
        draw_text(surface, "KRAKEN", 12, sx, sy - r - 30, GOLD, center=True)


class Gem:
    def __init__(self, x, y, value=5):
        self.x, self.y = x, y
        self.radius = GEM_RADIUS
        self.value = value
        self.anim_timer = random.uniform(0, math.pi * 2)

    def update(self, px, py, attract_range=GEM_ATTRACT_DIST):
        self.anim_timer += 0.1
        d = dist((self.x, self.y), (px, py))
        if d < attract_range:
            a = angle_to((self.x, self.y), (px, py))
            speed = GEM_ATTRACT_SPEED * (1 - d / attract_range) + 1
            self.x += math.cos(a) * speed
            self.y += math.sin(a) * speed

    def draw(self, surface, cam_x, cam_y):
        sx, sy = int(self.x - cam_x), int(self.y - cam_y)
        bob = math.sin(self.anim_timer) * 2
        sy_b = int(sy + bob)
        glow = pygame.Surface((20, 20), pygame.SRCALPHA)
        pygame.draw.circle(glow, (50, 200, 50, 40), (10, 10), 10)
        surface.blit(glow, (sx - 10, sy_b - 10))
        pts = [(sx, sy_b - self.radius), (sx + self.radius, sy_b),
               (sx, sy_b + self.radius), (sx - self.radius, sy_b)]
        pygame.draw.polygon(surface, GREEN, pts)
        pygame.draw.polygon(surface, WHITE, pts, 1)


class HealthPickup:
    def __init__(self, x, y, heal=20):
        self.x, self.y = x, y
        self.heal = heal
        self.radius = 8
        self.anim_timer = 0

    def update(self):
        self.anim_timer += 0.08

    def draw(self, surface, cam_x, cam_y):
        sx, sy = int(self.x - cam_x), int(self.y - cam_y)
        bob = math.sin(self.anim_timer) * 3
        sy_b = int(sy + bob)
        pygame.draw.rect(surface, RED, (sx - 6, sy_b - 2, 12, 4))
        pygame.draw.rect(surface, RED, (sx - 2, sy_b - 6, 4, 12))
        pygame.draw.rect(surface, WHITE, (sx - 7, sy_b - 7, 14, 14), 1)


class TreasureChest:
    def __init__(self, x, y):
        self.x, self.y = x, y
        self.radius = 14
        self.anim_timer = 0

    def update(self):
        self.anim_timer += 0.1

    def draw(self, surface, cam_x, cam_y):
        sx, sy = int(self.x - cam_x), int(self.y - cam_y)
        glow_val = int(20 + 15 * math.sin(self.anim_timer))
        glow = pygame.Surface((40, 40), pygame.SRCALPHA)
        pygame.draw.circle(glow, (255, 200, 50, glow_val), (20, 20), 20)
        surface.blit(glow, (sx - 20, sy - 20))
        pygame.draw.rect(surface, (139, 90, 43), (sx - 10, sy - 6, 20, 14))
        pygame.draw.rect(surface, (180, 120, 60), (sx - 10, sy - 10, 20, 6))
        pygame.draw.rect(surface, GOLD, (sx - 2, sy - 4, 4, 4))
        pygame.draw.rect(surface, WHITE, (sx - 11, sy - 11, 22, 20), 1)


class DamageNumber:
    def __init__(self, x, y, value, color=WHITE):
        self.x, self.y = x, y
        self.value = value
        self.color = color
        self.timer = 30
        self.vy = -1.5

    def update(self):
        self.y += self.vy
        self.vy *= 0.95
        self.timer -= 1

    def draw(self, surface, cam_x, cam_y):
        alpha = clamp(self.timer / 30, 0, 1)
        color = tuple(int(c * alpha) for c in self.color)
        sx, sy = int(self.x - cam_x), int(self.y - cam_y)
        draw_text(surface, str(self.value), 16, sx, sy, color, center=True)


# ===========================================================================
# Section 9: Achievements
# ===========================================================================
ACHIEVEMENT_DEFS = [
    {"id": "first_blood", "name": "First Blood", "desc": "Kill your first enemy",
     "check": lambda p, g: p.kills >= 1},
    {"id": "centurion", "name": "Centurion", "desc": "Kill 100 enemies in one run",
     "check": lambda p, g: p.kills >= 100},
    {"id": "slaughter", "name": "Slaughter", "desc": "Kill 500 enemies in one run",
     "check": lambda p, g: p.kills >= 500},
    {"id": "wave5", "name": "Wave Rider", "desc": "Survive 5 waves",
     "check": lambda p, g: g.wave >= 5},
    {"id": "wave10", "name": "Veteran", "desc": "Survive 10 waves",
     "check": lambda p, g: g.wave >= 10},
    {"id": "boss_slayer", "name": "Boss Slayer", "desc": "Defeat a boss",
     "check": lambda p, g: g.bosses_killed >= 1},
    {"id": "level10", "name": "Powered Up", "desc": "Reach level 10",
     "check": lambda p, g: p.level >= 10},
    {"id": "level20", "name": "Unstoppable", "desc": "Reach level 20",
     "check": lambda p, g: p.level >= 20},
    {"id": "dasher", "name": "Speed Demon", "desc": "Dash 50 times in one run",
     "check": lambda p, g: p.dashes_used >= 50},
    {"id": "survivor5", "name": "Survivor", "desc": "Survive for 5 minutes",
     "check": lambda p, g: g.game_time >= 300},
    {"id": "survivor10", "name": "Endurance", "desc": "Survive for 10 minutes",
     "check": lambda p, g: g.game_time >= 600},
    {"id": "rich", "name": "Treasure Hunter", "desc": "Collect 500 gold total",
     "check": lambda p, g: g.save["gold"] + p.gold >= 500},
]


class AchievementPopup:
    def __init__(self, name):
        self.name = name
        self.timer = 180
        self.y_offset = -40

    def update(self):
        self.timer -= 1
        if self.y_offset < 0:
            self.y_offset += 3

    def draw(self, surface):
        if self.timer <= 0:
            return
        alpha = min(1.0, self.timer / 30)
        y = 80 + int(self.y_offset)
        w, h = 280, 40
        x = SCREEN_W // 2 - w // 2
        bg = pygame.Surface((w, h), pygame.SRCALPHA)
        bg.fill((40, 40, 60, int(200 * alpha)))
        surface.blit(bg, (x, y))
        pygame.draw.rect(surface, GOLD, (x, y, w, h), 2)
        c = tuple(int(ch * alpha) for ch in GOLD)
        draw_text(surface, f"Achievement: {self.name}", 16,
                  SCREEN_W // 2, y + 20, c, center=True)


# ===========================================================================
# Section 10: Power-ups
# ===========================================================================
POWERUPS = [
    {"name": "Damage Up", "desc": "+30% projectile damage", "color": RED,
     "apply": lambda p: setattr(p, "proj_damage", int(p.proj_damage * 1.3))},
    {"name": "Speed Up", "desc": "+15% movement speed", "color": CYAN,
     "apply": lambda p: setattr(p, "speed", p.speed * 1.15)},
    {"name": "Multi-Shot", "desc": "+1 projectile", "color": ORANGE,
     "apply": lambda p: setattr(p, "proj_count", p.proj_count + 1)},
    {"name": "Fire Rate", "desc": "Shoot 25% faster", "color": YELLOW,
     "apply": lambda p: setattr(p, "proj_cooldown", max(5, int(p.proj_cooldown * 0.75)))},
    {"name": "Max HP Up", "desc": "+30 max HP & heal", "color": GREEN,
     "apply": lambda p: (setattr(p, "max_hp", p.max_hp + 30),
                         setattr(p, "hp", p.max_hp + 30))},
    {"name": "Orbital Blades", "desc": "Spinning blades orbit you", "color": CYAN,
     "apply": lambda p: setattr(p, "has_orbit", True),
     "condition": lambda p: not p.has_orbit},
    {"name": "Orbit+", "desc": "+2 blades, wider radius", "color": CYAN,
     "apply": lambda p: (setattr(p, "orbit_count", p.orbit_count + 2),
                         setattr(p, "orbit_radius", p.orbit_radius + 15)),
     "condition": lambda p: p.has_orbit},
    {"name": "Damage Aura", "desc": "Hurt nearby enemies", "color": PURPLE,
     "apply": lambda p: setattr(p, "has_aura", True),
     "condition": lambda p: not p.has_aura},
    {"name": "Aura+", "desc": "Bigger & stronger aura", "color": PURPLE,
     "apply": lambda p: (setattr(p, "aura_radius", p.aura_radius + 25),
                         setattr(p, "aura_damage", p.aura_damage + 5)),
     "condition": lambda p: p.has_aura},
    {"name": "Lightning", "desc": "Chain lightning weapon", "color": CYAN,
     "apply": lambda p: setattr(p, "weapon", "lightning"),
     "condition": lambda p: p.weapon != "lightning"},
    {"name": "Boomerang", "desc": "Returning blade weapon", "color": TEAL,
     "apply": lambda p: setattr(p, "weapon", "boomerang"),
     "condition": lambda p: p.weapon != "boomerang"},
    {"name": "Explosion", "desc": "Periodic AoE blast", "color": ORANGE,
     "apply": lambda p: setattr(p, "has_explosion", True),
     "condition": lambda p: not p.has_explosion},
    {"name": "Explosion+", "desc": "Bigger blast, more damage", "color": ORANGE,
     "apply": lambda p: (setattr(p, "explosion_radius", p.explosion_radius + 30),
                         setattr(p, "explosion_damage", p.explosion_damage + 15)),
     "condition": lambda p: p.has_explosion},
    {"name": "XP Magnet", "desc": "Double gem attract range", "color": GREEN,
     "apply": lambda p: None, "special": "magnet"},
]


def pick_powerups(player, count=3):
    available = [p for p in POWERUPS
                 if p.get("condition", lambda _: True)(player)]
    return random.sample(available, min(count, len(available)))


# ===========================================================================
# Section 11: Upgrade Shop
# ===========================================================================
SHOP_ITEMS = [
    {"key": "max_hp", "name": "Vitality", "desc": "+10 starting HP",
     "base_cost": 30, "color": GREEN},
    {"key": "damage", "name": "Power", "desc": "+5 base damage",
     "base_cost": 40, "color": RED},
    {"key": "speed", "name": "Agility", "desc": "+0.2 move speed",
     "base_cost": 35, "color": CYAN},
    {"key": "xp_bonus", "name": "Wisdom", "desc": "+10% XP gain",
     "base_cost": 50, "color": PURPLE},
]


def get_upgrade_cost(item, level):
    return item["base_cost"] + level * 20


# ===========================================================================
# Section 12: Main Game
# ===========================================================================
class Game:
    def __init__(self):
        pygame.init()
        self.save = load_save()
        self.fullscreen = self.save["settings"]["fullscreen"]
        flags = pygame.FULLSCREEN if self.fullscreen else 0
        self.screen = pygame.display.set_mode((SCREEN_W, SCREEN_H), flags)
        pygame.display.set_caption("Survivor")
        self.clock = pygame.time.Clock()
        self.sound = SoundManager()
        self.sound.set_volume(self.save["settings"]["sfx_volume"])
        self.particles = ParticleSystem()
        self.shake = ScreenShake()
        self.state = "menu"
        self.char_idx = 0
        self.show_fps = False
        self.achievement_popups = []
        self.gem_attract_range = GEM_ATTRACT_DIST
        self.menu_selection = 0
        self.settings_selection = 0
        self.shop_selection = 0
        # Auto-update check (runs in background thread)
        self.update_available = None  # (version, url) or None
        self.update_status = ""  # "", "checking", "downloading", "ready", "failed"
        # updater disabled for web
        self.reset()

    def _check_update(self):
        ver, url = check_for_update()
        if ver:
            self.update_available = (ver, url)
            self.update_status = "available"
        else:
            self.update_status = ""

    def _do_update(self):
        if not self.update_available:
            return
        ver, url = self.update_available
        self.update_status = "downloading"
        if download_and_apply_update(ver, url):
            self.update_status = "ready"
        else:
            self.update_status = "failed"

    def reset(self):
        self.player = Player(self.char_idx, self.save["upgrades"])
        self.enemies = []
        self.projectiles = []
        self.boomerangs = []
        self.lightnings = []
        self.explosions = []
        self.gems = []
        self.health_pickups = []
        self.chests = []
        self.dmg_numbers = []
        self.wave = 0
        self.wave_timer = 0
        self.spawn_timer = 0
        self.spawn_rate = INITIAL_SPAWN_RATE
        self.game_time = 0
        self.pending_powerups = []
        self.cam_x = self.cam_y = 0
        self.bosses_killed = 0
        self.boss_spawned_this_wave = False
        self.chest_timer = 0
        self.gem_attract_range = GEM_ATTRACT_DIST
        self.new_achievements = []

    def toggle_fullscreen(self):
        self.fullscreen = not self.fullscreen
        flags = pygame.FULLSCREEN if self.fullscreen else 0
        self.screen = pygame.display.set_mode((SCREEN_W, SCREEN_H), flags)
        self.save["settings"]["fullscreen"] = self.fullscreen
        save_game(self.save)

    # ----- achievement checking -----
    def check_achievements(self):
        for ach in ACHIEVEMENT_DEFS:
            if ach["id"] not in self.save["achievements"]:
                if ach["check"](self.player, self):
                    self.save["achievements"].append(ach["id"])
                    self.achievement_popups.append(AchievementPopup(ach["name"]))
                    self.sound.play("achievement")
                    self.new_achievements.append(ach["id"])

    # ----- spawning -----
    def spawn_enemy(self):
        angle = random.uniform(0, 2 * math.pi)
        d = random.uniform(SPAWN_DIST_MIN, SPAWN_DIST_MAX)
        x = clamp(self.player.x + math.cos(angle) * d, 0, WORLD_W)
        y = clamp(self.player.y + math.sin(angle) * d, 0, WORLD_H)
        self.enemies.append(Enemy(x, y, self.wave))

    def spawn_boss(self):
        angle = random.uniform(0, 2 * math.pi)
        x = clamp(self.player.x + math.cos(angle) * 500, 50, WORLD_W - 50)
        y = clamp(self.player.y + math.sin(angle) * 500, 50, WORLD_H - 50)
        self.enemies.append(Boss(x, y, self.wave))
        self.sound.play("boss_roar")
        self.shake.shake(10)

    def spawn_chest(self):
        angle = random.uniform(0, 2 * math.pi)
        d = random.uniform(100, 300)
        x = clamp(self.player.x + math.cos(angle) * d, 50, WORLD_W - 50)
        y = clamp(self.player.y + math.sin(angle) * d, 50, WORLD_H - 50)
        self.chests.append(TreasureChest(x, y))

    # ----- weapons -----
    def fire_weapons(self):
        p = self.player
        if not self.enemies:
            return

        nearest = min(self.enemies,
                      key=lambda e: dist((e.x, e.y), (p.x, p.y)))
        base_angle = angle_to((p.x, p.y), (nearest.x, nearest.y))

        if p.weapon == "projectile" and p.cooldown_timer <= 0:
            spread = 0.15
            for i in range(p.proj_count):
                offset = (i - (p.proj_count - 1) / 2) * spread
                self.projectiles.append(
                    Projectile(p.x, p.y, base_angle + offset,
                               p.proj_speed, p.proj_damage))
            p.cooldown_timer = p.proj_cooldown
            self.sound.play("shoot")

        if p.weapon == "lightning" and p.lightning_timer <= 0:
            targets = []
            hit = set()
            cx, cy = p.x, p.y
            for _ in range(p.lightning_chains):
                best, best_d = None, p.lightning_range
                for e in self.enemies:
                    if id(e) in hit:
                        continue
                    d2 = dist((cx, cy), (e.x, e.y))
                    if d2 < best_d:
                        best, best_d = e, d2
                if best:
                    targets.append((best.x, best.y))
                    hit.add(id(best))
                    best.hp -= p.proj_damage
                    best.hit_flash = 4
                    self.dmg_numbers.append(
                        DamageNumber(best.x, best.y - 10, p.proj_damage, CYAN))
                    self.particles.emit(best.x, best.y, CYAN, 5, 2, 10, 2, glow=True)
                    if best.hp <= 0:
                        self._kill_enemy(best)
                    cx, cy = best.x, best.y
                else:
                    break
            if targets:
                self.lightnings.append(LightningBolt(p.x, p.y, targets, p.proj_damage))
                p.lightning_timer = p.lightning_cooldown
                self.sound.play("lightning")

        if p.weapon == "boomerang" and p.boomerang_timer <= 0:
            for i in range(p.boomerang_count):
                offset = (i - (p.boomerang_count - 1) / 2) * 0.3
                self.boomerangs.append(
                    Boomerang(p.x, p.y, base_angle + offset, 6,
                              p.proj_damage, [p.x, p.y]))
            p.boomerang_timer = p.boomerang_cooldown
            self.sound.play("boomerang")

        if p.has_explosion and p.explosion_timer <= 0:
            self.explosions.append(
                ExplosionEffect(p.x, p.y, p.explosion_radius, p.explosion_damage))
            self.sound.play("explosion")
            self.shake.shake(6)
            self.particles.emit(p.x, p.y, ORANGE, 20, 5, 25, 4, glow=True)
            for e in self.enemies[:]:
                if dist((p.x, p.y), (e.x, e.y)) < p.explosion_radius + e.radius:
                    e.hp -= p.explosion_damage
                    e.hit_flash = 4
                    self.dmg_numbers.append(
                        DamageNumber(e.x, e.y - 10, p.explosion_damage, ORANGE))
                    if e.hp <= 0:
                        self._kill_enemy(e)
            p.explosion_timer = p.explosion_cooldown

    def _kill_enemy(self, enemy):
        if enemy not in self.enemies:
            return
        self.gems.append(Gem(enemy.x, enemy.y, enemy.xp_value))
        self.player.gold += enemy.gold_value
        self.particles.emit(enemy.x, enemy.y, enemy.color, 12, 4, 20, 3)
        if random.random() < enemy.drop_chance:
            self.health_pickups.append(
                HealthPickup(enemy.x, enemy.y, 15 + self.wave * 2))
        if enemy.is_boss:
            self.bosses_killed += 1
            self.shake.shake(15)
            self.particles.emit(enemy.x, enemy.y, GOLD, 30, 6, 30, 5, glow=True)
            self.sound.play("explosion")
        else:
            self.sound.play("kill")
        self.enemies.remove(enemy)
        self.player.kills += 1

    # ----- collisions -----
    def check_collisions(self):
        p = self.player

        for proj in self.projectiles[:]:
            for enemy in self.enemies[:]:
                if dist((proj.x, proj.y), (enemy.x, enemy.y)) < proj.radius + enemy.radius:
                    enemy.hp -= proj.damage
                    enemy.hit_flash = 4
                    self.dmg_numbers.append(
                        DamageNumber(enemy.x, enemy.y - 10, proj.damage, YELLOW))
                    self.particles.emit(proj.x, proj.y, YELLOW, 4, 2, 10, 2)
                    self.sound.play("hit")
                    if proj in self.projectiles:
                        self.projectiles.remove(proj)
                    if enemy.hp <= 0:
                        self._kill_enemy(enemy)
                    break

        for boom in self.boomerangs[:]:
            for enemy in self.enemies[:]:
                if id(enemy) in boom.hit_enemies:
                    continue
                if dist((boom.x, boom.y), (enemy.x, enemy.y)) < boom.radius + enemy.radius:
                    enemy.hp -= boom.damage
                    enemy.hit_flash = 4
                    boom.hit_enemies.add(id(enemy))
                    self.dmg_numbers.append(
                        DamageNumber(enemy.x, enemy.y - 10, boom.damage, TEAL))
                    self.particles.emit(boom.x, boom.y, TEAL, 3, 2, 8, 2)
                    self.sound.play("hit")
                    if enemy.hp <= 0:
                        self._kill_enemy(enemy)

        if p.has_orbit:
            for i in range(p.orbit_count):
                a = p.orbit_angle + (2 * math.pi * i / p.orbit_count)
                ox = p.x + math.cos(a) * p.orbit_radius
                oy = p.y + math.sin(a) * p.orbit_radius
                for enemy in self.enemies[:]:
                    if dist((ox, oy), (enemy.x, enemy.y)) < 8 + enemy.radius:
                        enemy.hp -= p.orbit_damage
                        enemy.hit_flash = 4
                        self.dmg_numbers.append(
                            DamageNumber(enemy.x, enemy.y - 10, p.orbit_damage, CYAN))
                        if enemy.hp <= 0:
                            self._kill_enemy(enemy)

        if p.has_aura and p.aura_tick % 15 == 0:
            for enemy in self.enemies[:]:
                if dist((p.x, p.y), (enemy.x, enemy.y)) < p.aura_radius + enemy.radius:
                    enemy.hp -= p.aura_damage
                    enemy.hit_flash = 3
                    if enemy.hp <= 0:
                        self._kill_enemy(enemy)

        for enemy in self.enemies:
            if dist((enemy.x, enemy.y), (p.x, p.y)) < enemy.radius + p.radius:
                if p.invuln_timer <= 0:
                    p.hp -= enemy.damage
                    p.invuln_timer = INVULN_TIME
                    self.dmg_numbers.append(
                        DamageNumber(p.x, p.y - 20, enemy.damage, RED))
                    self.particles.emit(p.x, p.y, RED, 8, 3, 15, 2)
                    self.sound.play("hurt")
                    self.shake.shake(5)
                    if p.hp <= 0:
                        self.end_run()

        for gem in self.gems[:]:
            if dist((gem.x, gem.y), (p.x, p.y)) < gem.radius + p.radius + 10:
                leveled = p.gain_xp(gem.value)
                self.gems.remove(gem)
                self.sound.play("gem")
                self.particles.emit(gem.x, gem.y, GREEN, 4, 2, 8, 2)
                if leveled:
                    p.powerups_chosen += 1
                    self.pending_powerups = pick_powerups(p)
                    self.state = "levelup"
                    self.sound.play("levelup")

        for hp_item in self.health_pickups[:]:
            if dist((hp_item.x, hp_item.y), (p.x, p.y)) < hp_item.radius + p.radius + 10:
                p.hp = min(p.max_hp, p.hp + hp_item.heal)
                self.health_pickups.remove(hp_item)
                self.sound.play("heal")
                self.dmg_numbers.append(
                    DamageNumber(p.x, p.y - 20, f"+{hp_item.heal}", GREEN))
                self.particles.emit(hp_item.x, hp_item.y, GREEN, 6, 2, 12, 2, glow=True)

        for chest in self.chests[:]:
            if dist((chest.x, chest.y), (p.x, p.y)) < chest.radius + p.radius + 10:
                self.chests.remove(chest)
                self.sound.play("chest")
                self.particles.emit(chest.x, chest.y, GOLD, 15, 4, 20, 3, glow=True)
                reward = random.choice(["heal", "gold", "powerup"])
                if reward == "heal":
                    p.hp = min(p.max_hp, p.hp + 50)
                    self.dmg_numbers.append(
                        DamageNumber(chest.x, chest.y - 20, "+50 HP", GREEN))
                elif reward == "gold":
                    bonus = 20 + self.wave * 5
                    p.gold += bonus
                    self.dmg_numbers.append(
                        DamageNumber(chest.x, chest.y - 20, f"+{bonus}g", GOLD))
                else:
                    self.pending_powerups = pick_powerups(p)
                    if self.pending_powerups:
                        self.state = "levelup"

    def end_run(self):
        self.save["gold"] += self.player.gold
        self.save["total_kills"] += self.player.kills
        self.save["total_runs"] += 1
        minutes = int(self.game_time) // 60
        seconds = int(self.game_time) % 60
        entry = {
            "time": f"{minutes:02d}:{seconds:02d}",
            "kills": self.player.kills,
            "level": self.player.level,
            "wave": self.wave + 1,
            "character": CHARACTERS[self.char_idx]["name"],
        }
        self.save["high_scores"].append(entry)
        self.save["high_scores"].sort(key=lambda s: s["kills"], reverse=True)
        self.save["high_scores"] = self.save["high_scores"][:10]
        save_game(self.save)
        self.state = "gameover"

    # ----- update -----
    def update(self):
        if self.state != "playing":
            return
        keys = pygame.key.get_pressed()
        p = self.player
        p.update(keys)

        for b in self.boomerangs:
            b.owner_ref[0] = p.x
            b.owner_ref[1] = p.y

        self.cam_x = p.x - SCREEN_W / 2 + self.shake.offset_x
        self.cam_y = p.y - SCREEN_H / 2 + self.shake.offset_y
        self.shake.update()

        self.game_time += 1 / FPS
        self.wave_timer += 1 / FPS
        if self.wave_timer >= WAVE_DURATION:
            self.wave_timer = 0
            self.wave += 1
            self.spawn_rate = max(MIN_SPAWN_RATE,
                                  int(INITIAL_SPAWN_RATE * (0.9 ** self.wave)))
            self.boss_spawned_this_wave = False

        if (self.wave > 0 and self.wave % BOSS_WAVE_INTERVAL == 0
                and not self.boss_spawned_this_wave):
            self.spawn_boss()
            self.boss_spawned_this_wave = True

        self.spawn_timer += 1
        if self.spawn_timer >= self.spawn_rate:
            self.spawn_timer = 0
            for _ in range(1 + self.wave // 3):
                self.spawn_enemy()

        self.chest_timer += 1
        if self.chest_timer >= FPS * 45:
            self.chest_timer = 0
            self.spawn_chest()

        self.fire_weapons()

        for proj in self.projectiles[:]:
            proj.update()
            if proj.life <= 0:
                self.projectiles.remove(proj)
        for boom in self.boomerangs[:]:
            boom.update()
            if boom.returned:
                self.boomerangs.remove(boom)
        for ln in self.lightnings[:]:
            ln.update()
            if ln.life <= 0:
                self.lightnings.remove(ln)
        for ex in self.explosions[:]:
            ex.update()
            if ex.life <= 0:
                self.explosions.remove(ex)
        for enemy in self.enemies:
            enemy.update(p.x, p.y)
        for gem in self.gems:
            gem.update(p.x, p.y, self.gem_attract_range)
        for hp_item in self.health_pickups:
            hp_item.update()
        for ch in self.chests:
            ch.update()
        for dn in self.dmg_numbers[:]:
            dn.update()
            if dn.timer <= 0:
                self.dmg_numbers.remove(dn)
        self.particles.update()
        for ap in self.achievement_popups[:]:
            ap.update()
            if ap.timer <= 0:
                self.achievement_popups.remove(ap)

        self.check_collisions()
        self.check_achievements()

    # ----- drawing -----
    def draw_ground(self):
        # Ocean background
        start_x = int(self.cam_x // TILE_SIZE) * TILE_SIZE
        start_y = int(self.cam_y // TILE_SIZE) * TILE_SIZE
        t = pygame.time.get_ticks() / 1000.0
        for tx in range(start_x, start_x + SCREEN_W + TILE_SIZE * 2, TILE_SIZE):
            for ty in range(start_y, start_y + SCREEN_H + TILE_SIZE * 2, TILE_SIZE):
                sx = tx - self.cam_x
                sy = ty - self.cam_y
                wave = math.sin(tx * 0.01 + t * 0.8) * 0.5 + 0.5
                wave2 = math.sin(ty * 0.007 + t * 0.6) * 0.5 + 0.5
                blend = (wave + wave2) / 2
                r = int(12 + blend * 15)
                g = int(40 + blend * 30)
                b = int(90 + blend * 40)
                color = (r, g, b)
                pygame.draw.rect(self.screen, color,
                                 (sx, sy, TILE_SIZE, TILE_SIZE))
                # Foam highlights on wave peaks
                if blend > 0.7:
                    foam_a = int((blend - 0.7) / 0.3 * 40)
                    foam = pygame.Surface((TILE_SIZE, TILE_SIZE), pygame.SRCALPHA)
                    foam.fill((200, 230, 255, foam_a))
                    self.screen.blit(foam, (sx, sy))

    def draw_minimap(self):
        mm = pygame.Surface((MINIMAP_SIZE, MINIMAP_SIZE), pygame.SRCALPHA)
        mm.fill((0, 0, 0, 120))
        sx = MINIMAP_SIZE / WORLD_W
        sy = MINIMAP_SIZE / WORLD_H
        pygame.draw.circle(mm, WHITE,
                           (int(self.player.x * sx), int(self.player.y * sy)), 2)
        for e in self.enemies:
            c = GOLD if e.is_boss else RED
            sz = 2 if e.is_boss else 1
            pygame.draw.circle(mm, c, (int(e.x * sx), int(e.y * sy)), sz)
        for ch in self.chests:
            pygame.draw.circle(mm, GOLD, (int(ch.x * sx), int(ch.y * sy)), 2)
        pygame.draw.rect(mm, LIGHT_GRAY, (0, 0, MINIMAP_SIZE, MINIMAP_SIZE), 1)
        self.screen.blit(mm, (SCREEN_W - MINIMAP_SIZE - MINIMAP_MARGIN,
                              SCREEN_H - MINIMAP_SIZE - MINIMAP_MARGIN))

    def draw_hud(self):
        p = self.player
        # Semi-transparent HUD background panels
        left_panel = pygame.Surface((220, 100), pygame.SRCALPHA)
        left_panel.fill((0, 0, 0, 100))
        self.screen.blit(left_panel, (5, 5))
        right_panel = pygame.Surface((150, 75), pygame.SRCALPHA)
        right_panel.fill((0, 0, 0, 100))
        self.screen.blit(right_panel, (SCREEN_W - 155, 5))

        # HP bar (rounded feel)
        draw_bar(self.screen, 12, 12, 204, 20, p.hp / p.max_hp, RED, DARK_RED)
        draw_text(self.screen, f"HP {p.hp}/{p.max_hp}", 14, 16, 14)
        # XP bar
        draw_bar(self.screen, 12, 38, 204, 14, p.xp / p.xp_to_next, (40, 100, 220), GRAY)
        draw_text(self.screen, f"Lv {p.level}", 13, 16, 38)
        # Gold with icon
        draw_text(self.screen, f"Gold: {p.gold}", 15, 14, 58, GOLD)
        # Weapon
        draw_text(self.screen, f"Weapon: {p.weapon.capitalize()}", 12, 14, 78, LIGHT_GRAY)
        draw_text(self.screen, "SPACE = dash", 11, 14, 92, GRAY)

        minutes = int(self.game_time) // 60
        seconds = int(self.game_time) % 60
        draw_text(self.screen, f"{minutes:02d}:{seconds:02d}", 20,
                  SCREEN_W - 145, 12, WHITE)
        draw_text(self.screen, f"Wave {self.wave + 1}", 16, SCREEN_W - 145, 36)
        draw_text(self.screen, f"Kills {p.kills}", 16, SCREEN_W - 145, 56, LIGHT_GRAY)

        if self.show_fps:
            draw_text(self.screen, f"FPS: {int(self.clock.get_fps())}", 14,
                      SCREEN_W - 80, SCREEN_H - 25, LIGHT_GRAY)

        self.draw_minimap()

    def draw_menu(self):
        self.screen.fill((10, 30, 60))
        draw_text(self.screen, "BOATRY", 64, SCREEN_W // 2, 100, GOLD, center=True)
        draw_text(self.screen, "McBOATERSON", 40, SCREEN_W // 2, 155, WHITE, center=True)
        items = ["Play", "Characters", "Upgrades", "Achievements",
                 "High Scores", "Settings", "Quit"]
        for i, item in enumerate(items):
            y = 260 + i * 45
            color = WHITE if i == self.menu_selection else GRAY
            prefix = "> " if i == self.menu_selection else "  "
            draw_text(self.screen, f"{prefix}{item}", 24,
                      SCREEN_W // 2, y, color, center=True)
        draw_text(self.screen, "Arrow keys to navigate, Enter to select", 14,
                  SCREEN_W // 2, SCREEN_H - 40, GRAY, center=True)
        # Update notification
        if self.update_status == "available" and self.update_available:
            ver = self.update_available[0]
            draw_text(self.screen, f"Update v{ver} available! Press U to update", 16,
                      SCREEN_W // 2, SCREEN_H - 65, GREEN, center=True)
        elif self.update_status == "downloading":
            draw_text(self.screen, "Downloading update...", 16,
                      SCREEN_W // 2, SCREEN_H - 65, YELLOW, center=True)
        elif self.update_status == "ready":
            draw_text(self.screen, "Update installed! Restart the game to apply.", 16,
                      SCREEN_W // 2, SCREEN_H - 65, GREEN, center=True)
        elif self.update_status == "failed":
            draw_text(self.screen, "Update failed. Try again later.", 16,
                      SCREEN_W // 2, SCREEN_H - 65, RED, center=True)
        # Version
        if HAS_UPDATER:
            draw_text(self.screen, f"v{get_current_version()}", 12,
                      SCREEN_W - 60, SCREEN_H - 20, GRAY)

    def draw_char_select(self):
        self.screen.fill(DARK_GRAY)
        draw_text(self.screen, "SELECT CHARACTER", 36,
                  SCREEN_W // 2, 60, GOLD, center=True)
        box_w, box_h = 220, 180
        total_w = len(CHARACTERS) * (box_w + 20)
        start_x = SCREEN_W // 2 - total_w // 2 + 10
        for i, ch in enumerate(CHARACTERS):
            bx = start_x + i * (box_w + 20)
            by = 130
            selected = i == self.char_idx
            border = WHITE if selected else GRAY
            pygame.draw.rect(self.screen, (40, 40, 55), (bx, by, box_w, box_h))
            pygame.draw.rect(self.screen, border, (bx, by, box_w, box_h),
                             3 if selected else 1)
            pygame.draw.rect(self.screen, ch["color"], (bx, by, box_w, 4))
            cx, cy = bx + box_w // 2, by + 50
            pygame.draw.circle(self.screen, ch["color"], (cx, cy), 20)
            pygame.draw.circle(self.screen, WHITE, (cx, cy), 20, 2)
            pygame.draw.circle(self.screen, WHITE, (cx - 5, cy - 4), 4)
            pygame.draw.circle(self.screen, WHITE, (cx + 5, cy - 4), 4)
            draw_text(self.screen, ch["name"], 22,
                      bx + box_w // 2, by + 90, ch["color"], center=True)
            draw_text(self.screen, ch["desc"], 12,
                      bx + box_w // 2, by + 115, LIGHT_GRAY, center=True)
            stats = (f"HP:{ch['hp_mod']:.0%} SPD:{ch['spd_mod']:.0%} "
                     f"DMG:{ch['dmg_mod']:.0%}")
            draw_text(self.screen, stats, 11,
                      bx + box_w // 2, by + 140, GRAY, center=True)
            draw_text(self.screen, f"Weapon: {ch['weapon']}", 11,
                      bx + box_w // 2, by + 158, GRAY, center=True)
        draw_text(self.screen, "Left/Right to choose, Enter to confirm, Esc back",
                  14, SCREEN_W // 2, SCREEN_H - 40, GRAY, center=True)

    def draw_shop(self):
        self.screen.fill(DARK_GRAY)
        draw_text(self.screen, "UPGRADES", 36, SCREEN_W // 2, 50, GOLD, center=True)
        draw_text(self.screen, f"Gold: {self.save['gold']}", 22,
                  SCREEN_W // 2, 95, GOLD, center=True)
        for i, item in enumerate(SHOP_ITEMS):
            y = 160 + i * 80
            level = self.save["upgrades"][item["key"]]
            cost = get_upgrade_cost(item, level)
            selected = i == self.shop_selection
            border = WHITE if selected else GRAY
            bx, bw, bh = SCREEN_W // 2 - 200, 400, 65
            pygame.draw.rect(self.screen, (40, 40, 55), (bx, y, bw, bh))
            pygame.draw.rect(self.screen, border, (bx, y, bw, bh),
                             2 if selected else 1)
            draw_text(self.screen, f"{item['name']} (Lv {level})", 20,
                      bx + 15, y + 10, item["color"])
            draw_text(self.screen, item["desc"], 14, bx + 15, y + 36, LIGHT_GRAY)
            cost_color = GREEN if self.save["gold"] >= cost else RED
            draw_text(self.screen, f"Cost: {cost}g", 16,
                      bx + bw - 100, y + 22, cost_color)
        draw_text(self.screen, "Enter to buy, Esc to go back", 14,
                  SCREEN_W // 2, SCREEN_H - 40, GRAY, center=True)

    def draw_achievements(self):
        self.screen.fill(DARK_GRAY)
        draw_text(self.screen, "ACHIEVEMENTS", 36,
                  SCREEN_W // 2, 50, GOLD, center=True)
        unlocked = self.save["achievements"]
        y = 120
        for ach in ACHIEVEMENT_DEFS:
            done = ach["id"] in unlocked
            color = GREEN if done else GRAY
            icon = "*" if done else "x"
            draw_text(self.screen, f"[{icon}] {ach['name']}", 18, 200, y, color)
            desc_color = LIGHT_GRAY if done else DARK_GRAY
            draw_text(self.screen, ach["desc"], 14, 500, y + 2, desc_color)
            y += 35
        draw_text(self.screen, f"{len(unlocked)}/{len(ACHIEVEMENT_DEFS)} unlocked",
                  16, SCREEN_W // 2, SCREEN_H - 60, LIGHT_GRAY, center=True)
        draw_text(self.screen, "Esc to go back", 14,
                  SCREEN_W // 2, SCREEN_H - 35, GRAY, center=True)

    def draw_high_scores(self):
        self.screen.fill(DARK_GRAY)
        draw_text(self.screen, "HIGH SCORES", 36,
                  SCREEN_W // 2, 50, GOLD, center=True)
        if not self.save["high_scores"]:
            draw_text(self.screen, "No scores yet. Go play!", 20,
                      SCREEN_W // 2, 200, GRAY, center=True)
        else:
            header = f"{'#':<4}{'Char':<10}{'Kills':<10}{'Wave':<8}{'Lv':<8}{'Time':<8}"
            draw_text(self.screen, header, 16, 180, 120, LIGHT_GRAY)
            for i, sc in enumerate(self.save["high_scores"][:10]):
                y = 155 + i * 30
                c = GOLD if i == 0 else (WHITE if i < 3 else LIGHT_GRAY)
                ch_name = sc.get("character", "?")
                row = (f"{i+1:<4}{ch_name:<10}{sc['kills']:<10}"
                       f"{sc['wave']:<8}{sc['level']:<8}{sc['time']:<8}")
                draw_text(self.screen, row, 15, 180, y, c)
        draw_text(self.screen,
                  f"Total runs: {self.save['total_runs']}  |  "
                  f"Total kills: {self.save['total_kills']}",
                  14, SCREEN_W // 2, SCREEN_H - 60, GRAY, center=True)
        draw_text(self.screen, "Esc to go back", 14,
                  SCREEN_W // 2, SCREEN_H - 35, GRAY, center=True)

    def draw_settings(self):
        self.screen.fill(DARK_GRAY)
        draw_text(self.screen, "SETTINGS", 36, SCREEN_W // 2, 80, GOLD, center=True)
        items = [
            ("SFX Volume", f"{int(self.save['settings']['sfx_volume'] * 100)}%"),
            ("Fullscreen", "On" if self.fullscreen else "Off"),
            ("FPS Counter (F3)", "On" if self.show_fps else "Off"),
        ]
        for i, (name, val) in enumerate(items):
            y = 200 + i * 60
            sel = i == self.settings_selection
            color = WHITE if sel else GRAY
            prefix = "> " if sel else "  "
            draw_text(self.screen, f"{prefix}{name}: {val}", 22,
                      SCREEN_W // 2, y, color, center=True)
            if sel:
                draw_text(self.screen, "Left/Right to adjust", 13,
                          SCREEN_W // 2, y + 25, GRAY, center=True)
        draw_text(self.screen, "Esc to go back  |  F11 toggle fullscreen", 14,
                  SCREEN_W // 2, SCREEN_H - 40, GRAY, center=True)

    def draw_pause(self):
        overlay = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 160))
        self.screen.blit(overlay, (0, 0))
        draw_text(self.screen, "PAUSED", 48,
                  SCREEN_W // 2, SCREEN_H // 2 - 40, WHITE, center=True)
        draw_text(self.screen, "Esc to resume  |  Q to quit to menu", 18,
                  SCREEN_W // 2, SCREEN_H // 2 + 20, LIGHT_GRAY, center=True)

    def draw_levelup(self):
        overlay = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 160))
        self.screen.blit(overlay, (0, 0))
        draw_text(self.screen, f"LEVEL UP!  (Lv {self.player.level})", 36,
                  SCREEN_W // 2, 100, GOLD, center=True)
        draw_text(self.screen, "Choose a power-up:", 20,
                  SCREEN_W // 2, 150, LIGHT_GRAY, center=True)
        box_w, box_h = 280, 90
        total = len(self.pending_powerups) * (box_w + 20)
        start_x = SCREEN_W // 2 - total // 2 + 10
        mx, my = pygame.mouse.get_pos()
        self.hovered_powerup = -1
        for i, pu in enumerate(self.pending_powerups):
            bx = start_x + i * (box_w + 20)
            by = 200
            hovered = bx <= mx <= bx + box_w and by <= my <= by + box_h
            if hovered:
                self.hovered_powerup = i
            border = WHITE if hovered else GRAY
            pygame.draw.rect(self.screen, (40, 40, 55), (bx, by, box_w, box_h))
            pygame.draw.rect(self.screen, border, (bx, by, box_w, box_h), 2)
            pygame.draw.rect(self.screen, pu["color"], (bx, by, box_w, 4))
            draw_text(self.screen, f"[{i+1}]  {pu['name']}", 20,
                      bx + 10, by + 15, pu["color"])
            draw_text(self.screen, pu["desc"], 15, bx + 10, by + 50, LIGHT_GRAY)

    def draw_gameover(self):
        overlay = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        self.screen.blit(overlay, (0, 0))
        draw_text(self.screen, "GAME OVER", 56,
                  SCREEN_W // 2, SCREEN_H // 3 - 20, RED, center=True)
        p = self.player
        minutes = int(self.game_time) // 60
        seconds = int(self.game_time) % 60
        stats = (f"Survived {minutes:02d}:{seconds:02d}  |  Kills {p.kills}"
                 f"  |  Level {p.level}  |  Wave {self.wave+1}")
        draw_text(self.screen, stats, 20,
                  SCREEN_W // 2, SCREEN_H // 2 - 20, LIGHT_GRAY, center=True)
        draw_text(self.screen, f"Gold earned: {p.gold}", 18,
                  SCREEN_W // 2, SCREEN_H // 2 + 15, GOLD, center=True)
        if self.new_achievements:
            names = [a["name"] for a in ACHIEVEMENT_DEFS
                     if a["id"] in self.new_achievements]
            draw_text(self.screen, f"New: {', '.join(names)}", 16,
                      SCREEN_W // 2, SCREEN_H // 2 + 45, GREEN, center=True)
        draw_text(self.screen, "Enter to play again  |  Esc for menu", 20,
                  SCREEN_W // 2, SCREEN_H // 2 + 80, WHITE, center=True)

    def draw(self):
        if self.state == "menu":
            self.draw_menu()
        elif self.state == "char_select":
            self.draw_char_select()
        elif self.state == "shop":
            self.draw_shop()
        elif self.state == "achievements":
            self.draw_achievements()
        elif self.state == "high_scores":
            self.draw_high_scores()
        elif self.state == "settings":
            self.draw_settings()
        elif self.state in ("playing", "paused", "levelup", "gameover"):
            self.draw_ground()
            for ch in self.chests:
                ch.draw(self.screen, self.cam_x, self.cam_y)
            for hp_item in self.health_pickups:
                hp_item.draw(self.screen, self.cam_x, self.cam_y)
            for gem in self.gems:
                gem.draw(self.screen, self.cam_x, self.cam_y)
            for ex in self.explosions:
                ex.draw(self.screen, self.cam_x, self.cam_y)
            for enemy in self.enemies:
                enemy.draw(self.screen, self.cam_x, self.cam_y)
            for proj in self.projectiles:
                proj.draw(self.screen, self.cam_x, self.cam_y)
            for boom in self.boomerangs:
                boom.draw(self.screen, self.cam_x, self.cam_y)
            for ln in self.lightnings:
                ln.draw(self.screen, self.cam_x, self.cam_y)
            self.player.draw(self.screen, self.cam_x, self.cam_y)
            self.particles.draw(self.screen, self.cam_x, self.cam_y)
            for dn in self.dmg_numbers:
                dn.draw(self.screen, self.cam_x, self.cam_y)
            self.draw_hud()
            for ap in self.achievement_popups:
                ap.draw(self.screen)
            if self.state == "paused":
                self.draw_pause()
            elif self.state == "levelup":
                self.draw_levelup()
            elif self.state == "gameover":
                self.draw_gameover()

    # ----- events -----
    def _apply_powerup(self, idx):
        if 0 <= idx < len(self.pending_powerups):
            pu = self.pending_powerups[idx]
            if pu.get("special") == "magnet":
                self.gem_attract_range *= 2
            else:
                pu["apply"](self.player)
            self.sound.play("select")
            self.state = "playing"

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_F11:
                    self.toggle_fullscreen()
                    continue
                if event.key == pygame.K_F3:
                    self.show_fps = not self.show_fps
                    continue

                if self.state == "menu":
                    if event.key in (pygame.K_UP, pygame.K_w):
                        self.menu_selection = (self.menu_selection - 1) % 7
                        self.sound.play("select")
                    elif event.key in (pygame.K_DOWN, pygame.K_s):
                        self.menu_selection = (self.menu_selection + 1) % 7
                        self.sound.play("select")
                    elif event.key == pygame.K_RETURN:
                        c = self.menu_selection
                        if c == 0:
                            self.reset()
                            self.state = "playing"
                        elif c == 1:
                            self.state = "char_select"
                        elif c == 2:
                            self.state = "shop"
                            self.shop_selection = 0
                        elif c == 3:
                            self.state = "achievements"
                        elif c == 4:
                            self.state = "high_scores"
                        elif c == 5:
                            self.state = "settings"
                            self.settings_selection = 0
                        elif c == 6:
                            return False
                    elif event.key == pygame.K_ESCAPE:
                        return False
                    elif event.key == pygame.K_u:
                        if self.update_status == "available" and self.update_available:
                            pass  # disabled for web

                elif self.state == "char_select":
                    if event.key in (pygame.K_LEFT, pygame.K_a):
                        self.char_idx = (self.char_idx - 1) % len(CHARACTERS)
                        self.sound.play("select")
                    elif event.key in (pygame.K_RIGHT, pygame.K_d):
                        self.char_idx = (self.char_idx + 1) % len(CHARACTERS)
                        self.sound.play("select")
                    elif event.key in (pygame.K_RETURN, pygame.K_ESCAPE):
                        self.state = "menu"

                elif self.state == "shop":
                    if event.key in (pygame.K_UP, pygame.K_w):
                        self.shop_selection = (self.shop_selection - 1) % len(SHOP_ITEMS)
                        self.sound.play("select")
                    elif event.key in (pygame.K_DOWN, pygame.K_s):
                        self.shop_selection = (self.shop_selection + 1) % len(SHOP_ITEMS)
                        self.sound.play("select")
                    elif event.key == pygame.K_RETURN:
                        item = SHOP_ITEMS[self.shop_selection]
                        level = self.save["upgrades"][item["key"]]
                        cost = get_upgrade_cost(item, level)
                        if self.save["gold"] >= cost:
                            self.save["gold"] -= cost
                            self.save["upgrades"][item["key"]] += 1
                            save_game(self.save)
                            self.sound.play("chest")
                        else:
                            self.sound.play("hurt")
                    elif event.key == pygame.K_ESCAPE:
                        self.state = "menu"

                elif self.state == "settings":
                    if event.key in (pygame.K_UP, pygame.K_w):
                        self.settings_selection = (self.settings_selection - 1) % 3
                        self.sound.play("select")
                    elif event.key in (pygame.K_DOWN, pygame.K_s):
                        self.settings_selection = (self.settings_selection + 1) % 3
                        self.sound.play("select")
                    elif event.key in (pygame.K_LEFT, pygame.K_a,
                                       pygame.K_RIGHT, pygame.K_d):
                        delta = (0.1 if event.key in (pygame.K_RIGHT, pygame.K_d)
                                 else -0.1)
                        if self.settings_selection == 0:
                            vol = clamp(
                                self.save["settings"]["sfx_volume"] + delta, 0, 1)
                            self.save["settings"]["sfx_volume"] = round(vol, 1)
                            self.sound.set_volume(vol)
                            save_game(self.save)
                            self.sound.play("select")
                        elif self.settings_selection == 1:
                            self.toggle_fullscreen()
                        elif self.settings_selection == 2:
                            self.show_fps = not self.show_fps
                    elif event.key == pygame.K_ESCAPE:
                        self.state = "menu"

                elif self.state in ("achievements", "high_scores"):
                    if event.key == pygame.K_ESCAPE:
                        self.state = "menu"

                elif self.state == "playing":
                    if event.key == pygame.K_ESCAPE:
                        self.state = "paused"
                    elif event.key == pygame.K_SPACE:
                        if self.player.start_dash(pygame.key.get_pressed()):
                            self.sound.play("dash")
                            self.particles.emit(
                                self.player.x, self.player.y,
                                self.player.char_color, 8, 3, 12, 3)

                elif self.state == "paused":
                    if event.key == pygame.K_ESCAPE:
                        self.state = "playing"
                    elif event.key == pygame.K_q:
                        self.state = "menu"

                elif self.state == "levelup":
                    idx = -1
                    if event.key == pygame.K_1: idx = 0
                    elif event.key == pygame.K_2: idx = 1
                    elif event.key == pygame.K_3: idx = 2
                    self._apply_powerup(idx)

                elif self.state == "gameover":
                    if event.key == pygame.K_RETURN:
                        self.reset()
                        self.state = "playing"
                    elif event.key == pygame.K_ESCAPE:
                        self.state = "menu"

            if event.type == pygame.MOUSEBUTTONDOWN and self.state == "levelup":
                if hasattr(self, "hovered_powerup"):
                    self._apply_powerup(self.hovered_powerup)

        return True

    # ----- main loop -----
    async def run(self):
        running = True
        while running:
            running = self.handle_events()
            self.update()
            self.draw()
            pygame.display.flip()
            self.clock.tick(FPS)
            await asyncio.sleep(0)
        pygame.quit()


async def main():
    game = Game()
    await game.run()

if __name__ == "__main__":
    asyncio.run(main())

